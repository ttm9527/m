import os
import shelve

from threading import Thread, RLock, active_count
from queue import Queue, Empty
from urllib.parse import urlparse
from hashlib import sha256
import json

from utils import get_logger, get_urlhash, normalize
from scraper import is_valid

from time import time, sleep
class Frontier(object):
    def __init__(self, config, restart):
        self.logger = get_logger("FRONTIER")
        self.config = config
        self.domain_map = {}
        self.to_be_downloaded = []
        self.lock = RLock()
        self.unique_urls = set()
        self.subdomains = set()
        
        if not os.path.exists(self.config.save_file) and not restart:
            # Save file does not exist, but request to load save.
            self.logger.info(
                f"Did not find save file {self.config.save_file}, "
                f"starting from seed.")
        elif os.path.exists(self.config.save_file) and restart:
            # Save file does exists, but request to start from seed.
            self.logger.info(
                f"Found save file {self.config.save_file}, deleting it.")
            os.remove(self.config.save_file)
        # Load existing save file, or create one if it does not exist.
        self.save = shelve.open(self.config.save_file)
        if restart:
            for url in self.config.seed_urls:
                self.add_url(url)
        else:
            # Set the frontier state with contents of save file.
            self._parse_save_file()
            if not self.save:
                for url in self.config.seed_urls:
                    self.add_url(url)

    def _parse_save_file(self):
        ''' This function can be overridden for alternate saving techniques. '''
        total_count = len(self.save)
        tbd_count = 0
        for url, completed in self.save.values():
            if not completed and is_valid(url):
                print(is_valid(url))
                self.to_be_downloaded.append(url)
                tbd_count += 1
        self.logger.info(
            f"Found {tbd_count} urls to be downloaded from {total_count} "
            f"total urls discovered.")

    def get_main_domain(self, url):
        raw_domain = urlparse(url).netloc
        return '.'.join(raw_domain.split('.')[-2:])

    def _pop_and_update(self, current):
        output = self.to_be_downloaded.pop()
        domain = self.get_main_domain(output)
        print(current - self.domain_map[domain][0], domain)
        self.domain_map[domain][0] = current
        return output
    def _refresh(self, current):
        empty = True
        for time_urls in self.domain_map.values():
            if time_urls[1]:
                empty=False
            print(current - time_urls[0])
            if current - time_urls[0] >= self.config.time_delay and time_urls[1]:
                new = time_urls[1].pop()
                print(new)
                self.to_be_downloaded.append(new)
        return empty
    def get_tbd_url(self):
        with self.lock:
            current = time()
            try:
                output = self._pop_and_update(current)
            except IndexError:
                empty = self._refresh(current)
                try:
                    output = self._pop_and_update(current)
                except IndexError:
                    if not empty:
                        sleep(self.config.time_delay)
                        current = time()
                        empty = self._refresh(current)
                        output = self._pop_and_update(current)
                    else:
                        print(active_count())
                        start = time()
                        while active_count() > 0 and time() - start> 60:
                            sleep(self.config.time_delay)
                            current = time()
                            empty = self._refresh(current)
                            try:
                                self._pop_and_update(current)
                            except IndexError:
                                pass
                        save_summary(self.subdomains, self.unique_urls)
                        return None
            return output

    def add_url(self, url):
        with self.lock:
            url = normalize(url)
            main_domain = self.get_main_domain(url)
            safe_to_add = False
            unique_hash = get_urlhash_no_frag(url)
            if unique_hash in self.unique_urls:
                return
            else:
                self.unique_urls.add(unique_hash)
            self.subdomains.add(urlparse(url).netloc)
            if main_domain not in self.domain_map: #if we have not seen this domain before
                self.domain_map[main_domain] = [time(),[]] # add a new entry in domain_map
                safe_to_add = True #add the url to to_be_downlaod immediately
            else:
                self.domain_map[main_domain][1].append(url) #if not, add the url to 
            urlhash = get_urlhash(url)
            if urlhash not in self.save:
                self.save[urlhash] = (url, False)
                self.save.sync()
                if safe_to_add:
                    self.to_be_downloaded.append(url)
            
    
    def mark_url_complete(self, url):
        with self.lock:
            urlhash = get_urlhash(url)
            if urlhash not in self.save:
                # This should not happen.
                self.logger.error(
                    f"Completed url {url}, but have not seen it before.")

            self.save[urlhash] = (url, True)
            self.save.sync()

def save_summary(set_1:set, set_2):
    output_summary = {
    "unique_urls": list(set_2),
    "domains": list(set_1)}
    json_object = json.dumps(output_summary, indent=4)
    
    with open(f"result/output_summary_{round(time())}.json", "w") as outfile:
        outfile.write(json_object)

def get_urlhash_no_frag(url):
    parsed = urlparse(url)
    return sha256(
        f"{parsed.netloc}/{parsed.path}/{parsed.params}/"
        f"{parsed.query}".encode("utf-8")).hexdigest()
