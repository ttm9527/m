import re
from urllib.parse import urlparse, urldefrag
from bs4 import BeautifulSoup
from time import time
from tokenizing import tokenize, computerWordFrequencies, words_50
from pathlib import Path
from threading import RLock
from hashlib import sha256

low_contents = set() 
long_page_num = 0 # the longest page count
long_page = "" # url
loop = 0
common_tokens = {}
write_lock = RLock()

previous_two = [[],[]]

def scraper(url, resp):
    links = extract_next_links(url, resp)
    return [link for link in links if is_valid(link)]

def extract_next_links(url, resp):
    # Implementation required.
    # url: the URL that was used to get the page
    # resp.url: the actual url of the page
    # resp.status: the status code returned by the server. 200 is OK, you got the page. Other numbers mean that there was some kind of problem.
    # resp.error: when status is not 200, you can check the error here, if needed.
    # resp.raw_response: this is where the page actually is. More specifically, the raw_response has two parts:
    #         resp.raw_response.url: the url, again
    #         resp.raw_response.content: the content of the page!
    # Return a list with the hyperlinks (as strings) scrapped from resp.raw_response.content
    global loop, low_contents, long_page_num, long_page

    loop = loop + 1

    if resp.status != 200 or resp.raw_response is None:
        low_contents.add(url)
        return[]

    recent_url = url

    contents = BeautifulSoup( resp.raw_response.content, 'html.parser')
    
    A_Links = contents.find_all('a')

    links = set() # to contain urls for return

    for link in A_Links:
        if 'href' in link.attrs: # if it's link
            new_url = link['href']
            new_url = urldefrag(new_url)[0]
            #print(new_url)
            try:
                if is_valid(new_url): # check if it's valid 
                    links.add(new_url)
                else:
                    low_contents.add(new_url)
            except ValueError as ex:
                report(ex, url)
    
    # text processing
    text = contents.get_text()
    #print(links)
    tokens = tokenize(text)
    if len(tokens) > 50:
        for token in tokens:
            if token in common_tokens:
                common_tokens[token] += 1
            else:
                common_tokens[token] = 1
        save(url, tokens)
        if len(tokens) > long_page_num:
            long_page_num = len(tokens)
            long_page = url
    else:
        print(url, tokens, "shortcontent")
    # if len(tokens) < 200: 
    #     links.discard(url)
    #     low_contents.add(url)
    # else:
    #     All_Tokens += tokens
    
    print("loop : ", loop)
    print("url : ", url)
    print("current_longest : ", long_page_num)
    #questions(url,text)
    return links

def is_valid(url):
    # Decide whether to crawl this url or not. 
    # If you decide to crawl it, return True; otherwise return False.
    # There are already some conditions that return False.
    try:
        parsed = urlparse(url)
        
        if parsed.scheme not in set(["http", "https"]):
            return False
        
        if url in low_contents:
            return False

        if len(url) > 150:
            return False
        
        allowed_words = {".ics.uci.edu/", ".cs.uci.edu/", ".informatics.uci.edu/",
                         ".stat.uci.edu/", "today.uci.edu/department/information_computer_sciences/"}

        flag = False

        for words in allowed_words:
            if words in (f"{parsed.netloc}{parsed.path}").lower():
                flag = True
        
        if flag == False:
            return False
        
        avoid_words = {"calendar", "login", "events", "uploads", "pdf"}

        for words in avoid_words:
            if words in url.lower():
                print("avoid", url)
                return False

        avoid_query = ["action=download&upname"]
        for words in avoid_words:
            if words in parsed.query.lower():
                print("avoid", url)
                return False

        return not re.match(
            r".*\.(css|js|bmp|gif|jpe?g|ico"
            + r"|png|tiff?|mid|mp2|mp3|mp4"
            + r"|wav|avi|mov|mpeg|ram|m4v|mkv|ogg|ogv|pdf"
            + r"|ps|eps|tex|ppt|pptx|doc|docx|xls|xlsx|names"
            + r"|data|dat|exe|bz2|tar|msi|bin|7z|psd|dmg|iso"
            + r"|epub|dll|cnf|tgz|sha1"
            + r"|thmx|mso|arff|rtf|jar|csv"
            + r"|rm|smil|wmv|swf|wma|zip|rar|gz)$", (parsed.path+parsed.query).lower())

    except TypeError:
        print ("TypeError for ", parsed)
        raise


def save(url, tokens):
    global long_page_num, long_page
    with write_lock:
        file_name = Path(f"result/website_{urlparse(url).netloc}.txt") 
        if file_name.exists():
            outfile = open(file_name, "a")
        else:
            outfile =  open(file_name, "w")
        outfile.write(f"{url}||{tokens}\n")
        outfile.close()
        with open(f"result/meta_info.txt", "w") as meta:
            common_words = words_50(common_tokens)
            meta.write(f"{long_page}:{long_page_num}||{common_words}")
        console = Path(f"result/console_log.txt") 
        if file_name.exists():
            outfile = open(console, "a")
        else:
            outfile =  open(console, "w")
        outfile.write(f"{url}||{tokens}\n")



def report(ex, url, option=None):
    with write_lock:
        with open(f"result/bug_report_{time()}", "w") as meta:
            meta.write(f"{ex}:{url}")
"""
def find_ngrams(input_list, n):
    return zip(*[input_list[i:] for i in range(n)])

def similar(tokens):
    global previous_two
    fingers = find_ngrams(tokens, 3)
    fingerprint = []
    for finger in fingers:
        if sha256(finger)%4 == 0:
            fingerprint.append()
    for 

"""