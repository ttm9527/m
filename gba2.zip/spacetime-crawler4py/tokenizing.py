import string
import sys

StopWords = set()
with open("stopwords.txt") as file:
    for word in file:
        StopWords.add(word.strip())

def tokenize(text):
    tokens = []  
    word = "" # O(1) for assignment
    for letter in text:
        if letter.isalnum(): # For a n length string, its O(n) time, since we are only checking 1 character, it's O(1) time
            word += letter.lower() # O(1), O(n) for a length n string
        elif len(word) > 0:
            if word not in StopWords:
                tokens.append(word) # O(1) for appending elements in list by amortized analysis
            word = "" # O(1) for re-assgining variable 
        
    return tokens

def computerWordFrequencies(tokens):
    word_count = {} # O(1) for creating a dictionary object and make a refrence to it. 
    for token in tokens: # O(n) since this loop goes over all token in list
        if token in word_count: # Dictionary is a hashmap, so checking if an element is in dictionary takes O(1) time.
            word_count[token] += 1 # O(1) for re-assigning values
            # This is merely a short hand for a = a+1
        else:
            word_count[token] = 1 # O(1) for re-assigning values
    return word_count

def words_50(words):
    words = sorted(words.items(), key=lambda x: x[1], reverse=False)
    common_words = [key for key, value in words[:50]]
    return common_words